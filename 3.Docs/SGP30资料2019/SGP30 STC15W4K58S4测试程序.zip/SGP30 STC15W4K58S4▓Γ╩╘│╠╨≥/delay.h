#ifndef __delay_H__
#define __delay_H__

#define uchar unsigned char 
#define uint  unsigned int 
void Delay1000ms(void);
void delay85ms(void);
void delay29ms(void);
void delay15ms(void);
void delay2us(void) ;
void delay_ms(uint);
void Delay25ms(void);


#endif