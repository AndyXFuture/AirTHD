var searchData=
[
  ['template_20files',['Template Files',['../_templates_pg.html',1,'']]]
];
