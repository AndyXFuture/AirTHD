Arduino library for Sensirion SHT30-APR and SHT31-ARP Analog Humidity & Temperature Sensors
===========================================================================================
ClosedCube SHT30A-EASY and SHT31A-PRO breakout boards

[![](https://github.com/closedcube/B005_SHT30A_EASY/blob/master/images/B005_SHT30A-EASY_Small.jpg)](https://github.com/closedcube/B005_SHT30A_EASY)

[![](https://github.com/closedcube/B007_SHT31A_PRO/blob/master/images/B007_SHT31A-PRO_Small.jpg)](https://github.com/closedcube/B007_SHT31A_PRO)


