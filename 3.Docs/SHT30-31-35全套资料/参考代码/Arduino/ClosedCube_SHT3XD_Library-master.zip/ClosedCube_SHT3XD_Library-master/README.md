Arduino library for Sensirion SHT30-DIS and SHT31-DIS Digital Humidity & Temperature Sensors
============================================================================================
ClosedCube SHT30D-EASY and SHT31D-PRO breakout boards

[![](https://github.com/closedcube/B006_SHT30D_EASY/blob/master/images/B006_SHT30D-EASY_Small.jpg)](https://github.com/closedcube/B006_SHT30D_EASY)

[![](https://github.com/closedcube/B008_SHT31D_PRO/blob/master/images/B008_SHT31D-PRO_Small.jpg)](https://github.com/closedcube/B008_SHT31D_PRO)


